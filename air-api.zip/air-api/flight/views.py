import json
from django.shortcuts import render
from django.shortcuts import HttpResponse  # 导入HttpResponse模块
from datetime import datetime
from flight.models import Flight
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage, InvalidPage

def list(request):  # request是必须带的实例。类似class下方法必须带self一样  
    res=Flight.objects.filter().all()
    resList=[]
    for p in res:
        college = {}
        college['id'] =p.id
        college['airCode'] =p.airCode
        college['create_time'] =p.create_time
        college['status'] =p.status
        college['reserve1'] =p.reserve1
        college['reserve2'] =p.reserve2
        college['reserve3'] =p.reserve3
        college['reserve4'] =p.reserve4
        college['reserve5'] =p.reserve5
        college['comCode'] =p.comCode
        college['flag'] =p.flag
        college['fliAaddress'] =p.fliAaddress
        college['fliAtime'] =p.fliAtime
        college['fliBaddress'] =p.fliBaddress
        college['fliBtime'] =p.fliBtime
        college['fliCfare'] =p.fliCfare
        college['fliCnumber'] =p.fliCnumber
        college['fliDiscount'] =p.fliDiscount
        college['fliFfare'] =p.fliFfare
        college['fliFnumber'] =p.fliFnumber
        college['fliNo'] =p.fliNo
        college['fliRefundtime'] =p.fliRefundtime
        college['fliYfare'] =p.fliYfare
        college['fliYnumber'] =p.fliYnumber
        resList.append(college)   
    content = {
                'success': True,
                'message': '查询成功',
                'data':resList
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def info(request):  # request是必须带的实例。类似class下方法必须带self一样  
    query_dict = request.GET
    id = query_dict.get('id')  
    re=Flight.objects.get(id=id)
    newre={}
    newre['id'] =re.id
    newre['airCode'] =re.airCode
    newre['create_time'] =re.create_time
    newre['status'] =re.status
    newre['reserve1'] =re.reserve1
    newre['reserve2'] =re.reserve2
    newre['reserve3'] =re.reserve3
    newre['reserve4'] =re.reserve4
    newre['reserve5'] =re.reserve5
    newre['comCode'] =re.comCode
    newre['flag'] =re.flag
    newre['fliAaddress'] =re.fliAaddress
    newre['fliAtime'] =re.fliAtime
    newre['fliBaddress'] =re.fliBaddress
    newre['fliBtime'] =re.fliBtime
    newre['fliCfare'] =re.fliCfare
    newre['fliCnumber'] =re.fliCnumber
    newre['fliDiscount'] =re.fliDiscount
    newre['fliFfare'] =re.fliFfare
    newre['fliFnumber'] =re.fliFnumber
    newre['fliNo'] =re.fliNo
    newre['fliRefundtime'] =re.fliRefundtime
    newre['fliYfare'] =re.fliYfare
    newre['fliYnumber'] =re.fliYnumber
    content = {
                'success': True,
                'message': '查询成功',
                'data':newre
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def delete(request):  # request是必须带的实例。类似class下方法必须带self一样  
    query_dict = request.GET
    id = query_dict.get('id')  
    re=Flight.objects.get(id=id).delete()   
    content = {
                'success': True,
                'message': '删除成功',             
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')

def save(request):
    jsonData = json.loads(request.body.decode())
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    flight=Flight()
    try:
        flight.airCode=jsonData['airCode']
    except Exception:
        print("airCode is null")
    try:
        flight.status=jsonData['status']
    except Exception:
        print("status is null")
    try:
        flight.reserve1=jsonData['reserve1']
    except Exception:
        print("reserve1 is null")
    try:
        flight.reserve2=jsonData['reserve2']
    except Exception:
        print("reserve2 is null")
    try:
        flight.reserve3=jsonData['reserve3']
    except Exception:
        print("reserve3 is null")
    try:
        flight.reserve4=jsonData['reserve4']
    except Exception:
        print("reserve4 is null")
    try:
        flight.reserve5=jsonData['reserve5']
    except Exception:
        print("reserve5 is null")
    try:
        flight.comCode=jsonData['comCode']
    except Exception:
        print("comCode is null")
    try:
        flight.flag=jsonData['flag']
    except Exception:
        print("flag is null")
    try:
        flight.fliAaddress=jsonData['fliAaddress']
    except Exception:
        print("fliAaddress is null")
    try:
        flight.fliAtime=jsonData['fliAtime']
    except Exception:
        print("fliAtime is null")
    try:
        flight.fliBaddress=jsonData['fliBaddress']
    except Exception:
        print("fliBaddress is null")
    try:
        flight.fliBtime=jsonData['fliBtime']
    except Exception:
        print("fliBtime is null")
    try:
        flight.fliCfare=jsonData['fliCfare']
    except Exception:
        print("fliCfare is null")
    try:
        flight.fliCnumber=jsonData['fliCnumber']
    except Exception:
        print("fliCnumber is null")
    try:
        flight.fliDiscount=jsonData['fliDiscount']
    except Exception:
        print("fliDiscount is null")
    try:
        flight.fliFfare=jsonData['fliFfare']
    except Exception:
        print("fliFfare is null")
    try:
        flight.fliFnumber=jsonData['fliFnumber']
    except Exception:
        print("fliFnumber is null")
    try:
        flight.fliNo=jsonData['fliNo']
    except Exception:
        print("fliNo is null")
    try:
        flight.fliRefundtime=jsonData['fliRefundtime']
    except Exception:
        print("fliRefundtime is null")
    try:
        flight.fliYfare=jsonData['fliYfare']
    except Exception:
        print("fliYfare is null")
    try:
        flight.fliYnumber=jsonData['fliYnumber']
    except Exception:
        print("fliYnumber is null")
    flight.create_time=now	
    flight.save()
    content = {
                    'success': True,
                    'message': '新增成功',
                    'data':jsonData
                }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def update (request):
    jsonData = json.loads(request.body.decode())
    re = Flight.objects.get(id=jsonData['id'])
    try:
        re.airCode=jsonData['airCode']
    except Exception:
        print("airCode is null")
    try:
        re.status=jsonData['status']
    except Exception:
        print("status is null")
    try:
        re.reserve1=jsonData['reserve1']
    except Exception:
        print("reserve1 is null")
    try:
        re.reserve2=jsonData['reserve2']
    except Exception:
        print("reserve2 is null")
    try:
        re.reserve3=jsonData['reserve3']
    except Exception:
        print("reserve3 is null")
    try:
        re.reserve4=jsonData['reserve4']
    except Exception:
        print("reserve4 is null")
    try:
        re.reserve5=jsonData['reserve5']
    except Exception:
        print("reserve5 is null")
    try:
        re.comCode=jsonData['comCode']
    except Exception:
        print("comCode is null")
    try:
        re.flag=jsonData['flag']
    except Exception:
        print("flag is null")
    try:
        re.fliAaddress=jsonData['fliAaddress']
    except Exception:
        print("fliAaddress is null")
    try:
        re.fliAtime=jsonData['fliAtime']
    except Exception:
        print("fliAtime is null")
    try:
        re.fliBaddress=jsonData['fliBaddress']
    except Exception:
        print("fliBaddress is null")
    try:
        re.fliBtime=jsonData['fliBtime']
    except Exception:
        print("fliBtime is null")
    try:
        re.fliCfare=jsonData['fliCfare']
    except Exception:
        print("fliCfare is null")
    try:
        re.fliCnumber=jsonData['fliCnumber']
    except Exception:
        print("fliCnumber is null")
    try:
        re.fliDiscount=jsonData['fliDiscount']
    except Exception:
        print("fliDiscount is null")
    try:
        re.fliFfare=jsonData['fliFfare']
    except Exception:
        print("fliFfare is null")
    try:
        re.fliFnumber=jsonData['fliFnumber']
    except Exception:
        print("fliFnumber is null")
    try:
        re.fliNo=jsonData['fliNo']
    except Exception:
        print("fliNo is null")
    try:
        re.fliRefundtime=jsonData['fliRefundtime']
    except Exception:
        print("fliRefundtime is null")
    try:
        re.fliYfare=jsonData['fliYfare']
    except Exception:
        print("fliYfare is null")
    try:
        re.fliYnumber=jsonData['fliYnumber']
    except Exception:
        print("fliYnumber is null")
    re.save()
    content = {
                    'success': True,
                    'message': '修改成功',
                    'data':jsonData
                }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def page(request):  # request是必须带的实例。类似class下方法必须带self一样   
    data = json.loads(request.body.decode())
    pageNum = data['pageNum']
    pagesize = data['pageSize']
    search = data['search']
    res1=[]
    if search:
        res1=Flight.objects.filter(reserve1=search)
    else:
        res1=Flight.objects.filter()
        #Pagination
    total = res1.count()
    p = Paginator(res1, pagesize) # Show 10 contacts per page.
    page=[]
    try:
        page = p.page(pageNum)
    except PageNotAnInteger:
        page = p.page(pageNum)
    except EmptyPage:
        page = p.page(pageNum)
    resList=[]
    for p in page:
        college = {} 
        college['id'] =p.id
        college['airCode'] =p.airCode
        college['create_time'] =p.create_time
        college['status'] =p.status
        college['reserve1'] =p.reserve1
        college['reserve2'] =p.reserve2
        college['reserve3'] =p.reserve3
        college['reserve4'] =p.reserve4
        college['reserve5'] =p.reserve5
        college['comCode'] =p.comCode
        college['flag'] =p.flag
        college['fliAaddress'] =p.fliAaddress
        college['fliAtime'] =p.fliAtime
        college['fliBaddress'] =p.fliBaddress
        college['fliBtime'] =p.fliBtime
        college['fliCfare'] =p.fliCfare
        college['fliCnumber'] =p.fliCnumber
        college['fliDiscount'] =p.fliDiscount
        college['fliFfare'] =p.fliFfare
        college['fliFnumber'] =p.fliFnumber
        college['fliNo'] =p.fliNo
        college['fliRefundtime'] =p.fliRefundtime
        college['fliYfare'] =p.fliYfare
        college['fliYnumber'] =p.fliYnumber
        resList.append(college)        
    content = {
                    'success': True,
                    'message': '查询成功',
                    'data':resList,
                    'total':total
                }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def page1(request):  # request是必须带的实例。类似class下方法必须带self一样   fliBaddress
    data = json.loads(request.body.decode())
    pageNum = data['pageNum']
    pagesize = data['pageSize']
    search = data['search']
    res1=[]
    search = dict()
    if search:
        search['reserve1']=search
    if data['fliBaddress']:
        search['fliBaddress']=data['fliBaddress']
    if data['fliAaddress']:
        search['fliAaddress']=data['fliAaddress']
    if data['fliBtime']:
        search['fliBtime']=data['fliBtime']   
    res1=Flight.objects.filter(**search)
    total = res1.count()
    p = Paginator(res1, pagesize) # Show 10 contacts per page.
    page=[]
    try:
        page = p.page(pageNum)
    except PageNotAnInteger:
        page = p.page(pageNum)
    except EmptyPage:
        page = p.page(pageNum)
    resList=[]
    for p in page:
        college = {} 
        college['id'] =p.id
        college['airCode'] =p.airCode
        college['create_time'] =p.create_time
        college['status'] =p.status
        college['reserve1'] =p.reserve1
        college['reserve2'] =p.reserve2
        college['reserve3'] =p.reserve3
        college['reserve4'] =p.reserve4
        college['reserve5'] =p.reserve5
        college['comCode'] =p.comCode
        college['flag'] =p.flag
        college['fliAaddress'] =p.fliAaddress
        college['fliAtime'] =p.fliAtime
        college['fliBaddress'] =p.fliBaddress
        college['fliBtime'] =p.fliBtime
        college['fliCfare'] =p.fliCfare
        college['fliCnumber'] =p.fliCnumber
        college['fliDiscount'] =p.fliDiscount
        college['fliFfare'] =p.fliFfare
        college['fliFnumber'] =p.fliFnumber
        college['fliNo'] =p.fliNo
        college['fliRefundtime'] =p.fliRefundtime
        college['fliYfare'] =p.fliYfare
        college['fliYnumber'] =p.fliYnumber
        resList.append(college)        
    content = {
                    'success': True,
                    'message': '查询成功',
                    'data':resList,
                    'total':total
                }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')